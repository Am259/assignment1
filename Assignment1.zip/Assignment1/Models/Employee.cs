    using System.ComponentModel.DataAnnotations;
namespace MvcAssignment1.Models
{
    public class Employee
    {
        public int Id { get; set; }

       [Required]
     [MinLength(3)]
       public required string Name { get; set; }

       [Required]
      [MinLength(3)]
        public required string Surname { get; set; }

        [DataType(DataType.Date)]
        public DateTime BirthDate { get; set; }

         [Required]
       [MinLength(3)]
        public required string Position { get; set; }
        public required string Image { get; set; }

        internal static string? FirstOrDefault(Func<object, bool> value)
        {
            throw new NotImplementedException();
        }
    }
}
