using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using MvcAssignment1.Models;

namespace Aaaignment1.Controllers;

[DebuggerDisplay($"{{{nameof(GetDebuggerDisplay)}(),nq}}")]
public class EmployeeController : Controller
{
    private List<Employee> _employees;
    private object? model;

    public EmployeeController()
    {
        _employees = new List<Employee>
        {
            new() {
                Id = 0,
                Name = "Martin",
                Surname = "Simpson",
                BirthDate = new DateTime(1992, 12, 3),
                Position = "Marketing Expert",
                Image = "/images/Martin.jpg"
            },
            new() {
                Id = 1,
                Name = "Jacob",
                Surname = "Hawk",
                BirthDate = new DateTime(1995, 10, 2),
                Position = "Manager",
                Image = "/images/Jacob.jpg"
            },
            new() {
                Id = 2,
                Name = "Elizabeth",
                Surname = "Geil",
                BirthDate = new DateTime(2000, 1, 7),
                Position = "Software Engineer",
                Image = "/images/Elizabeth.jpg"
            },
            new() {
                Id = 3,
                Name = "Kate",
                Surname = "Metain",
                BirthDate = new DateTime(1997, 2, 13),
                Position = "Admin",
                Image = "/images/Kate.jpg"
            },
            new() {
                Id = 4,
                Name = "Michael",
                Surname = "Cook",
                BirthDate = new DateTime(1990, 12, 25),
                Position = "Marketing expert",
                Image = "/images/Michael.jpg"
            },
            new() {
                Id = 5,
                Name = "John",
                Surname = "Snow",
                BirthDate = new DateTime(2001, 7, 15),
                Position = "Software Engineer",
                Image = "/images/John.jpg"
            },
            new() {
                Id = 6,
                Name = "Nina",
                Surname = "Soprano",
                BirthDate = new DateTime(1999, 9, 30),
                Position = "Software Engineer",
                Image = "/images/Nina.jpg"
            },
            new() {
                Id = 7,
                Name = "Tina",
                Surname = "Fins",
                BirthDate = new DateTime(2000, 5, 14),
                Position = "Team Leader",
                Image = "/images/Tina.jpg"
            }
        };
    }

    public ActionResult Index()
    {
         ViewBag.Layout = "_Lab2Layout";
        return View(_employees);
    }

    public ActionResult Details(int id)
    {
         ViewBag.Layout = "_Lab2Layout";
        var employee = _employees.FirstOrDefault(e => e.Id == id);
        return View(employee);
    }

    private string GetDebuggerDisplay()
    {
        return ToString();
    }
    public ActionResult Edit(int id)
    {
         ViewBag.Layout = "_Lab2Layout";
        var employee = _employees.FirstOrDefault(e => e.Id == id);
        return View(employee);
    }
    
 public ActionResult Update(int id)
    {
         ViewBag.Layout = "_Lab2Layout";
        var employee = _employees.FirstOrDefault(e => e.Id == id);
        return View(employee);
    }

}